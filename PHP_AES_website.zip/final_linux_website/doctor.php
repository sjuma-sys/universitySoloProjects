<?php

require_once ("functions.php");
$dbc = dbconnect();
//print_r($_SESSION);
$key = 'qkwjdiw239&&jdafweihbrhnan&^%$ggdnawhd4njshjwuuO';
if (!isset($_SESSION['user']) || $_SESSION['doctor'] != True) {
    (header('location: login.php'));
	echo "Still not set";
}
if (isset($_POST['Selectmeds']) && (isset($_POST['Selectpatienttoassignto'])) && !empty($_POST['medicationnotes'])){
        $meds = enc($_POST['Selectmeds'], $key);
        $note = enc(sanitisation($_POST['medicationnotes']), $key);
        $conn = dbconnect();
        $patientsql = Sqlstatements($conn, 'SELECT P_Name from patients;');
        $patientsqls = $patientsql -> fetch_assoc();
        $encpat = $patientsqls['P_Name']; //encrypted patient
        $result = Sqlstatements($conn, 'Select D_Name from doctors where D_User=?','s',$_SESSION['encvalue']);
        if ($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                $drname = $row['D_Name'];       //we also have the encrypted doctors name
                }
        }
 SqlInsertion($conn,'INSERT into patientsmedication values(?, ?, ?,?)','ssss',$meds,$encpat,$drname,$note);
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style type="text/css">

.css1{
position:absolute;top:0px;left:0px;
width:16px;height:16px;
font-family:Arial,sans-serif;
font-size:16px;
text-align:center;
font-weight:bold;
}
.css2{
position:absolute;top:0px;left:0px;
width:10px;height:10px;
font-family:Arial,sans-serif;
font-size:10px;
text-align:center;
}

</style>


<title>Doctor portal</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

header {
  background-color: green;
  padding: 30px;
  text-align: center;
  font-size: 35px;
  color: black;
}

nav ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

nav li {
  float: left;
}

nav li a {
  display: block;
  color: #f1f1f1;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

nav li a:hover {
 
     background-color: #111;
    }
    section{
        background-color: #f1f1f1;
    }
article {
  float: left;
  padding: 20px;
  width: 50%;
  background-color: #f1f1f1;

}
    
aside {
  float: right;
  padding: 20px;
  width: 50%;
  background-color: #f1f1f1;

}



section:after {
  content: "";
  display: table;
  clear: both;
}


footer {
  background-color: green;
  padding: 10px;
  text-align: center;
  color: green;
}

@media (max-width: 600px) {
  nav, article {
    width: 100%;
    height: auto;
  }
}
</style>
</head>
<body>



<header>
  <h2>Doctor</h2>
</header>
<nav>
    <ul>
    <li><a href="logout.php">logout</a></li>
    </ul>
    </nav>
<nav>
    <ul>
    
 
    </ul>
    </nav>
      

<section>

  <script type="text/javascript" src="otherconcepts.js"></script>
  <form name="submitmeds" id="submitmeds"method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">

<!-- <div> -->
      Select the medication that you would like to assign:
<?php
            $conn = dbconnect();
            echo "<select name='Selectmeds'>";
            $result = Sqlstatements($conn, 'SELECT meds from medication');
            if ($result -> num_rows > 0) {
            while ($row = $result -> fetch_assoc()) {
            echo "<option value=".dec($row['meds'],$key).">".dec($row['meds'],$key)."</option>";
                  }
            } else {echo "Database error"; }
            ?>
        </select>
<!-- </div>   -->
<!-- </section> -->
<!-- <section> -->
            <br>
    Notes regarding that medication<input type="text" id="medicationnotes" name="medicationnotes">

            <br><br>

      Select a patient you would like to assign it to:
            <?php
            $conn = dbconnect();
            echo "<select name='Selectpatienttoassignto'>";
            $result = Sqlstatements($conn, 'SELECT P_Name from patients');       //working
            if ($result -> num_rows > 0) {
            while ($row = $result -> fetch_assoc()) {
            echo "<label> 'Doctors username:' </label>";
            echo "Patients Name: <option value=".dec($row['P_Name'],$key)." id='rudeboy'>".dec($row['P_Name'],$key)."</option>";
                  }
            } else {echo "Database error"; }
            ?>
            </select>
            <br> <br>
            <div>
        </div>
<br> 

                   <button id="submitmeds" type="submit">Send
            </button>  
        </form>
</section>

        <br> <br> <br> <br>


        <?php
$conn = dbconnect();
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$result = Sqlstatements($conn, 'SELECT * from bookappointments where Do_User=?','s',$_SESSION['encvalue']);
// $result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "
    <section>
    <table><tr><th>Patients Name</th><th>Doctors Name</th><th>Patients note:</th><th>Appointment</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".dec($row["Pa_Name"], $key)."</td><td>Dr. ".dec($row['Do_Name'], $key)."</td><td>".dec($row['Pa_Note'],$key)."</td><td>".dec($row['Pa_App'],$key)."</td></tr>";
    }
    echo "</table> </section>";
} else {
    echo "0 results";
}

$result = Sqlstatements($conn, 'SELECT * from medication');
if ($result->num_rows > 0) {
    echo "
    <section>
    <table><tr><th>Mediaction</th><th>Recommended dosage</th><th>Usecase </th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".dec($row["meds"],$key)."</td><td>".dec($row["dosage"],$key)."</td><td>".dec($row['usecase'],$key)."</td></tr>";
    }
    echo "</table> </section>";
} else {
    echo "0 results";
}

$dname = Sqlstatements($conn, 'Select D_Name from doctors where D_User=?','s',$_SESSION['encvalue']);
$name = $dname ->fetch_assoc();

$result = Sqlstatements($conn, 'SELECT * from patientsmedication where Doc_Name=?','s',$name['D_Name']);
if ($result->num_rows > 0) {
    echo "
    <section>
    <table><tr><th>Medication</th><th>Patients name</th><th>Doctors Name</th><th>Medication notes</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".dec($row["prescmed"],$key)."</td><td>".dec($row["Pat_Name"], $key)."</td><td>Dr. ".dec($row['Doc_Name'], $key)."</td><td>".dec($row["Medsnote"], $key)."</td></tr>";
    }
    echo "</table> </section>";
} else {
    echo "0 results for prescribed medication";
}

$conn->close();

?>


        
     </body>
  </html>

    </div>
  
  </form>
  </section>
   
  </article>
</section>
    
  
    <footer>
  <p></p>
</footer>
  
 
</body>
</html>
