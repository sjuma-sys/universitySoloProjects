<?php 
require_once 'functions.php';
if (isset($_SESSION['user'])){
    session_destroy();
    header('location: login.php');   
} else {
    header('location: login.php');        
}


 ?>