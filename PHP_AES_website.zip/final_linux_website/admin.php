<?php
require_once('functions.php');

if (!isset($_SESSION['user']) || $_SESSION['admin'] != True) {
    (header('location: login.php'));
}
if (isset($_POST['patientchangedname'])) {              //working block
        if (!empty($_POST['patientchangedname'])) {
                $key = 'qkwjdiw239&&jdafweihbrhnan&^%$ggdnawhd4njshjwuuO';
                $conn = dbconnect();
                $pchange = sanitisation($_POST['patientchangedname']);
                $pnameenc = enc($pchange, $key);
                
                $psql = Sqlstatements($conn, 'SELECT P_Name from patients');
                $psqlresult = $psql ->fetch_assoc();
                $penc = $psqlresult['P_Name'];

                $pnewname = SqlUpdate($conn,'UPDATE patients set P_Name = ? where P_Name = ?;','ss', $pnameenc, $penc);

        }
}
if (isset($_POST['docchangedname'])) {
        if ($_POST['docchangedname'] != '' ) {
                $conn = dbconnect();
		$key = 'qkwjdiw239&&jdafweihbrhnan&^%$ggdnawhd4njshjwuuO';

                $dnamechange = sanitisation($_POST['docchangedname']);
                $dnamechangeenc = enc($dnamechange,$key);

                $dnamesql = Sqlstatements($conn, 'SELECT D_Name from doctors');
                $dnamefet = $dnamesql ->fetch_assoc();
                $dnameenc = $dnamefet['D_Name'];

                $dnewname = SqlUpdate($conn,'UPDATE doctors set D_Name = ? where D_Name = ?','ss', $dnamechangeenc, $dnameenc);
        }

}

if (isset($_POST['changeddob'])) {
        if ($_POST['changeddob']!= '') {
                $conn = dbconnect();
                $dob = sanitisation($_POST['changeddob']);
                $dobchange = enc($dob, $key);
                
                $dobsql = Sqlstatements($conn, 'SELECT DOB from patients');
                $dobsqlfet = $dobsql ->fetch_assoc();
                $dobenc = $dobsqlfet['DOB'];

                $pnewdob = SqlUpdate($conn,'UPDATE patients set DOB = ? where DOB = ?','ss', $dobchange, $dobenc);
        }

}


if (isset($_POST['changedaddress'])) {
        if ($_POST['changedaddress'] != '') {
                $conn = dbconnect();
                $addchange = sanitisation($_POST['changedaddress']);
                $addchangeenc = enc($addchange, $key);
                
                $addsql = Sqlstatements($conn, 'SELECT Address from patients');
                $addenc = $addsql ->fetch_assoc();
                $ogaddress = $addenc['Address'];
                
                $letsfo = SqlUpdate($conn,'UPDATE patients set Address = ? where Address = ?','ss', $addchangeenc, $ogaddress);     
                }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style type="text/css">
<!--


.css1{
position:absolute;top:0px;left:0px;
width:16px;height:16px;
font-family:Arial,sans-serif;
font-size:16px;
text-align:center;
font-weight:bold;
}
.css2{
position:absolute;top:0px;left:0px;
width:10px;height:10px;
font-family:Arial,sans-serif;
font-size:10px;
text-align:center;
}

</style>


<title>Our Team</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

header {
  background-color: green;
  padding: 30px;
  text-align: center;
  font-size: 35px;
  color: black;
}

nav ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

nav li {
  float: left;
}

nav li a {
  display: block;
  color: #f1f1f1;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

nav li a:hover {
 
     background-color: #111;
    }
    section{
        background-color: #f1f1f1;
    }
article {
  float: left;
  padding: 20px;
  width: 50%;
  background-color: #f1f1f1;

}
    
aside {
  float: right;
  padding: 20px;
  width: 50%;
  background-color: #f1f1f1;

}



section:after {
  content: "";
  display: table;
  clear: both;
}


footer {
  background-color: green;
  padding: 10px;
  text-align: center;
  color: green;
}

@media (max-width: 600px) {
  nav, article {
    width: 100%;
    height: auto;
  }
}
</style>
</head>
<body>



<header>
  <h2>Admin site</h2>
</header>
<nav>
    <ul>
    <li><a href="logout.php">logout</a></li>
    </ul>
    </nav>
<nav>
    <ul>
    
 
    </ul>
    </nav>

<script>window.name = "<?=$_POST['encvalue']?>";</script>
  <form name="entrydata" id="entrydata"method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">

    <section>
<!-- <div> -->
      Select the doctors name you would like to change:
                    <?php
            $conn = dbconnect();
            echo "<select name='Selectdoctorchange'>";
            $result = Sqlstatements($conn, 'SELECT D_Name from doctors');       //working
            if ($result -> num_rows > 0) {
            while ($row = $result -> fetch_assoc()) {
            echo "<label> 'Doctors username:' </label>";
            echo "<option value=".dec($row['D_Name'], $key).">".dec($row['D_Name'], $key)."</option>";
                  }
            } else {echo "Database error"; }
            ?>
            </select>
<!-- </div>   -->
</section>
<section>
            <br>
    Name you want to change it to for doctor <input type="text" id="docchangedname" name="docchangedname">

            <br><br>

      Select a Change for the patients name:
                    <?php
                    $conn = dbconnect();
            echo "<select name='Selectpatientchange'>";
            $result = Sqlstatements($conn, 'SELECT P_Name from patients');
            if ($result -> num_rows > 0) {
            while ($row = $result -> fetch_assoc()) {
	     
            echo "<label> 'Doctors username:' </label>";
            echo "Patients Name: <option value=".dec($row['P_Name'], $key).">".dec($row['P_Name'], $key)."</option>";
                  }
            } else {echo "Database error"; }
            ?>
            </select>
            <br> <br>
            <div>
          Name you want to change patients to<input type="text" id="patientchangedname" name="patientchangedname">
        </div>
<br> 
</section>
<section>
       Change the patients date of birth:
                    <?php
	    $key = 'qkwjdiw239&&jdafweihbrhnan&^%$ggdnawhd4njshjwuuO';
            $conn = dbconnect();
            echo "<select name='Selectdobchange'>";
            $result = Sqlstatements($conn, 'SELECT DOB from patients');       //working
            if ($result -> num_rows > 0) {
            while ($row = $result -> fetch_assoc()) {
            echo "<label> 'Doctors username:' </label>";
            echo "Patients Name: <option value=".dec($row['DOB'], $key)." id='rudeboy'>".dec($row['DOB'], $key)."</option>";
                  }
            } else {echo "Database error"; } 
            ?>
            </select>
            <br><br>
              <div>
    DOB you want to change it to<input type="text" id="changeddob" name="changeddob">
            </div>

            <br><br>
</section>

<section>
       Change the patients Address:
                    <?php
            $key = 'qkwjdiw239&&jdafweihbrhnan&^%$ggdnawhd4njshjwuuO';
            $conn = dbconnect();
            echo "<select name='selectaddress'>";
            $result = Sqlstatements($conn, 'SELECT Address from patients');       //working
            if ($result -> num_rows > 0) {
            while ($row = $result -> fetch_assoc()) {
            echo "<label> 'Doctors username:' </label>";
            echo "Patients Name: <option value=".dec($row['Address'], $key)." id='rudeboy'>".dec($row['Address'], $key)."</option>";
                  }
            } else {echo "Database error"; } 
            ?>
            </select>
            <br><br>
              <div>
    Address you want to change it to<input type="text" id="changedaddress" name="changedaddress">
            </div>

            <br><br>
</section>




            <input type="submit" id="submitregister" type=submit>
        </form>

        <br> <br> <br> <br>


        <?php


$conn = dbconnect();
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$key = 'qkwjdiw239&&jdafweihbrhnan&^%$ggdnawhd4njshjwuuO';

$result = Sqlstatements($conn, 'SELECT * from bookappointments');
// $result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "
    <section>
    <table><tr><th>Patients Name</th><th>Patients User</th><th>Doctors Name</th><th>Doctors user</th><th>Patients note:       </th><th>Appointment</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".dec($row["Pa_Name"], $key)."</td><td>".dec($row["Pa_User"], $key)."</td><td>".dec($row['Do_Name'], $key)."</td><td>".dec($row['Do_User'], $key)."</td><td>".dec($row['Pa_Note'], $key)."</td><td>".dec($row['Pa_App'], $key)."</td></tr>";
    }
    echo "</table> </section>";
} else {
    echo "0 results for booked appointments";
}

$result = Sqlstatements($conn, 'SELECT * from patients');
// $result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "
    <section>
    <table><tr><th>Patients Name</th><th>Patients User</th><th>Adress</th><th>DOB</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".dec($row["P_Name"], $key)."</td><td>".dec($row["P_User"], $key)."</td><td>".dec($row['Address'], $key)."</td><td>".dec($row['DOB'],$key)."</td></tr>";
    }
    echo "</table> </section>";
} else {
    echo "0 results";
}




$conn->close();
exit();
?>



     </body>
  </html>

    </div>

  </form>
  </section>

  </article>
</section>


    <footer>
  <p></p>
</footer>


</body>
</html>
