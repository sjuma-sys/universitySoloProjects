<?php
require_once('functions.php');
//https://www.foxinfotech.in/2019/01/process-combo-box-values-using-php.html
if (!isset($_SESSION['user']) || $_SESSION['patient'] != True) {
    (header('location: login.php'));
}
$conn = dbconnect();
$key = 'qkwjdiw239&&jdafweihbrhnan&^%$ggdnawhd4njshjwuuO';
if (isset($_POST['Selectionbox']) && isset($_POST['Pa_App']) && isset($_POST['Pa_Note'])) {
    $selectedDr_Name = $_POST['Selectionbox'];
    $Pa_User = $_SESSION['encvalue'];

    $App_Time = sanitisation($_POST['Pa_App']);
    $Pa_App = (str_replace("T"," ",$App_Time));
    $encapptime = enc($Pa_App, $key);
    
    $Pa_Note = sanitisation($_POST['Pa_Note']);
    $encpanote = enc($Pa_Note, $key);

    // echo json_encode($Pa_Note); //we get formatted DD/MM/YYYY HH:MM
    $sthiddenvalue = Sqlstatements($conn,'SELECT D_User from doctors');
    $row1 = $sthiddenvalue -> fetch_assoc(); 
    $docuser = $row1['D_User'];
        
    

      $docnamesql = Sqlstatements($conn, 'SELECT D_Name from doctors where D_User=?','s',$docuser);
      $docnamefet = $docnamesql -> fetch_assoc();
      $Dr_Name = $docnamefet['D_Name'];
      
    $ndhiddenvalue = Sqlstatements($conn,'SELECT P_Name from patients where P_User=?','s' ,$_SESSION['encvalue']);
    

    $row2 = $ndhiddenvalue -> fetch_assoc(); 
    $pname = $row2['P_Name'];
          
        

    $sql = SqlInsertion($conn, 'INSERT into bookappointments values( ?, ?,?,?, ?, ?)','ssssss', $pname,$Pa_User,$docuser,$Dr_Name,$encpanote,$encapptime);

        }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style type="text/css">


.css1{
position:absolute;top:0px;left:0px;
width:16px;height:16px;
font-family:Arial,sans-serif;
font-size:16px;
text-align:center;
font-weight:bold;
}
.css2{
position:absolute;top:0px;left:0px;
width:10px;height:10px;
font-family:Arial,sans-serif;
font-size:10px;
text-align:center;
}
</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="otherconcepts.js"></script>
  <title>Patient portal</title>
  <style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

header {
  background-color: green;
  padding: 30px;
  text-align: center;
  font-size: 35px;
  color: black;
}

nav ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

nav li {
  float: left;
}

nav li a {
  display: block;
  color: #f1f1f1;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

nav li a:hover {

     background-color: #111;
    }
    section{
        background-color: #f1f1f1;
    }
article {
  float: left;
  padding: 20px;
  width: 50%;
  background-color: #f1f1f1;

}

aside {
  float: right;
  padding: 20px;
  width: 50%;
  background-color: #f1f1f1;

}



section:after {
  content: "";
  display: table;
  clear: both;
}


footer {
  background-color: green;
  padding: 10px;
  text-align: center;
  color: green;
}

@media (max-width: 600px) {
  nav, article {
    width: 100%;
    height: auto;
  }
}
</style>
</head>
<body>

  <header>
  <h2>Patiennt</h2>
</header>
<nav>
    <ul>
    <li><a href="logout.php">logout</a></li>
    </ul>
    </nav>
<nav>
    <ul>


    </ul>
    </nav>
<section class="bookappointment">


  <article>
    <p>Book appointment</p>

  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"])?>" method="post" name="submitapp" id="submitapp">

            <label>Doctors name</label>
            <?php
            $conn = dbconnect();
            echo "<select name='Selectionbox'>";
            $result = Sqlstatements($conn, 'SELECT D_Name from doctors');       //working
            if ($result -> num_rows > 0) {
            while ($row = $result -> fetch_assoc()) {
            echo "<label> 'Patients username:' </label>";
            echo "<option value=".dec($row['D_Name'], $key).">".dec($row['D_Name'], $key)."</option>";
                  }
            } else {echo "Database error"; }
            ?>
            </select>

            <div class='patentsnotes'>
            What are your symptoms?: <input type="text" id="Pa_Note" name="Pa_Note"><br>
            </div>

            <div class="patientappointment">
            Patients appointment time:
            <input type="datetime-local" id="Pa_App" name="Pa_App" min="2022-10-31T21:00" max="2032-10-31T00:00"> <br>
            <br>
            </div>
            <div class="button input">
            <button id="submitpatient" type="submit">Send
            </button>
            </div>

        </form>
      </article>
    </section>

    <section>
<?php
      $conn = dbconnect();
$pname = Sqlstatements($conn, 'Select P_Name from patients where P_User=?','s',$_SESSION['encvalue']);
      $name = $pname ->fetch_assoc();
$result = Sqlstatements($conn, 'SELECT * from patientsmedication where Pat_Name=?','s',$name['P_Name']);
if ($result->num_rows > 0) {
    echo "
    <section>
    <table><tr><th>Medication</th><th>Doctors Name</th><th>Medication notes</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".dec($row["prescmed"],$key)." </td><td>Dr. ".dec($row['Doc_Name'],$key)."</td><td>".dec($row["Medsnote"],$key)."</td></tr>";
    }
    echo "</table> </section>";
} else {
    echo "0 results for prescribed medication";
}
$result = Sqlstatements($conn, 'SELECT * from bookappointments where Pa_User=?','s',$_SESSION['encvalue']);
// $result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "
    <section>
    <table><tr><th>Patients Name</th><th>Doctors Name</th><th>Patients note:</th><th>Appointment</th><tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".dec($row["Pa_Name"],$key)."</td><td>Dr. ".dec($row['Do_Name'],$key)."</td><td>".dec($row['Pa_Note'],$key)."</td><td>".dec($row['Pa_App'],$key)."</td></tr>";
    }
    echo "</table> </section>";
} else {
    echo "0 results";
}


$conn->close();
exit();
?>


    </section>
    <footer>
</footer>

</body>
</html>
