<?php 
    $maxlifetime = 0;
    $secure = false; // if you only want to receive the cookie over HTTPS
    $httponly = true; // prevent JavaScript access to session cookie
    $samesite = 'lax';

    if(PHP_VERSION_ID < 70300) {
        session_set_cookie_params($maxlifetime, '/; samesite='.$samesite, $_SERVER['HTTP_HOST'], $secure, $httponly);
    } else {
        session_set_cookie_params([
            'lifetime' => $maxlifetime,
            'path' => '/',
            'domain' => $_SERVER['HTTP_HOST'],
            'secure' => $secure,
            'httponly' => $httponly,
            'samesite' => $samesite
        ]);
    }
session_start();

function sanitisation($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
// error_reporting(0);


function dbconnect() {
	$dbname = "M00804482Said";
	$dbuser = "M00804482Said";
	$dbpass = "J3ronhi6oe?/";
	$servername = "localhost";

	$dbconnection = new mysqli($servername,$dbuser,$dbpass,$dbname); //this is for home
	if ($dbconnection -> connect_errno){
  		echo "Failed to connect to MySQL: " . $dbconnection -> connect_error;
	  	exit();
		}
	return $dbconnection;
}

function Sqlstatements($dbconnection, $query, $format = false, ...$vars){
	$statment = $dbconnection ->prepare($query);
	if ($format) {	//if format is ok
		$statment ->bind_param($format, ...$vars);	//put together an sql statement
	}
	if($statment->execute()) {		//if the statment has executed
		$result = $statment->get_result();	//
		$statment->close();
		return $result;
	}
	$statment -> close();
	return false;
}

function SqlInsertion($dbconnection, $query, $format = false, ...$vars){
	$statment = $dbconnection ->prepare($query);
	if ($format) {	//if format is ok
		$statment ->bind_param($format, ...$vars);	//put together an sql statement
	}
	if($statment->execute()) {		//if the statment has executed
		$id = $statment->insert_id;	//
		$statment->close();
		return $id;
	}
	$statment -> close();
	return -1;	//-1 is an illegal id
}

function SqlUpdate($C, $query, $format = false, ...$vars) {
		$stmt = $C->prepare($query);
		if($format) {
			$stmt->bind_param($format, ...$vars);
			}
			if($stmt->execute()) {
				$stmt->close();
				return true;
		}
		$stmt->close();
		return false;
	}

$key = 'qkwjdiw239&&jdafweihbrhnan&^%$ggdnawhd4njshjwuuO';
//ENCRYPT FUNCTION
function enc($data, $key) {
$encryption_key = base64_decode($key);
$iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
$encrypted = openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, $iv);
return base64_encode($encrypted . '::' . $iv);
}

//dec FUNCTION
function dec($data, $key) {
$encryption_key = base64_decode($key);
list($encrypted_data, $iv) = array_pad(explode('::', base64_decode($data), 2),2,null);
return openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $iv);
}
