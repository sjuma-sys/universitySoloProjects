<?php 
require_once('functions.php');
$dbc = dbconnect();
if (isset($_POST['username']) && isset($_POST['password'])) {
$key = 'qkwjdiw239&&jdafweihbrhnan&^%$ggdnawhd4njshjwuuO';
  $costofthehash = 12;

  $username = sanitisation($_POST['username']);
  $password = sanitisation($_POST['password']);
if ($dbc) {
  $hourbefore = time() - 60*60;
  $resultant = Sqlstatements($dbc, 'SELECT ip,timestamp,id,COUNT(loginattempts.id) FROM loginattempts WHERE user=? and timestamp > ? GROUP by id;', 'si', $username, $hourbefore);          
  $admincheckresult = Sqlstatements($dbc, 'SELECT A_User from admins;');
  $doctorcheckresult = Sqlstatements($dbc, 'SELECT D_User from doctors;');
  $patientcheckresult = Sqlstatements($dbc, 'SELECT P_User from patients;');

  if ($admincheckresult && $admincheckresult-> num_rows > 0){
      $encuser = $admincheckresult -> fetch_assoc();
      $decuser = dec($encuser['A_User'], $key);
      $enuser = $encuser['A_User'];
      if ($decuser == $username){
          $userpassfromdb = Sqlstatements($dbc, 'SELECT A_Pass from admins');
          $encpassfromdb = $userpassfromdb-> fetch_assoc();
          $decpass = dec($encpassfromdb['A_Pass'], $key);
          $passhash = password_verify($password, $decpass);

          if ($passhash){
              $_SESSION['loggedin'] = 'admin';
              $_SESSION['admin'] = true;
              $_SESSION['user'] = $username;
              $_SESSION['doctor'] = false;
              $_SESSION['patient'] = false;
              $_SESSION['encvalue'] = $enuser;
              SqlUpdate($dbc, 'DELETE FROM loginattempts WHERE user=?', 's',$username);
              header('location: admin.php');
          } else{ SqlInsertion($dbc, 'INSERT INTO loginattempts values(NULL ,?, ?, ?)','ssi', $username, $_SERVER['REMOTE_ADDR'],time()); }
	   }
  }
if ($patientcheckresult && $patientcheckresult-> num_rows > 0){
      $encp = $patientcheckresult -> fetch_assoc();
      $decuser = dec($encp['P_User'], $key);
      $penuser = $encp['P_User'];
      if ($decuser == $username){
          $userpassfromdb = Sqlstatements($dbc, 'SELECT P_Pass from patients');
          $encpassfromdb = $userpassfromdb-> fetch_assoc();
          $decpass = dec($encpassfromdb['P_Pass'], $key);
          $passhash = password_verify($password, $decpass);

          if ($passhash){
              $_SESSION['loggedin'] = 'patient';
              $_SESSION['patient'] = true;
              $_SESSION['user'] = $username;
              $_SESSION['doctor'] = false;
              $_SESSION['admin'] = false;
              $_SESSION['encvalue'] = $penuser;
              SqlUpdate($dbc, 'DELETE FROM loginattempts WHERE user=?', 's',$username);
              header('location: patient.php');
          } else{
                SqlInsertion($dbc, 'INSERT INTO loginattempts values(NULL ,?, ?, ?)','ssi', $username, $_SERVER['REMOTE_ADDR'],time());
        }
        }
    }

  if ($doctorcheckresult && $doctorcheckresult-> num_rows > 0){
      $encduser = $doctorcheckresult -> fetch_assoc();
      $doctorenc = $encduser['D_User'];
      $decduser = dec($encduser['D_User'], $key);
      if ($decduser == $username){
          $userpassfromdb = Sqlstatements($dbc, 'SELECT D_Pass from doctors');
          $encpassfromdb = $userpassfromdb-> fetch_assoc();
          $decpass = dec($encpassfromdb['D_Pass'], $key);
          $pasdshash = password_verify($password, $decpass);
        if ($pasdshash){
            $_SESSION['loggedin'] = 'doctor';
            $_SESSION['admin'] = false;
            $_SESSION['user'] = $username;
            $_SESSION['doctor'] = true;
            $_SESSION['patient'] = false;
            $_SESSION['encvalue'] = $doctorenc;
            SqlUpdate($dbc, 'DELETE FROM loginattempts WHERE user=?', 's',$username);
            header('location: doctor.php');
          } else{
                SqlInsertion($dbc, 'INSERT INTO loginattempts values(NULL ,?, ?, ?)','ssi', $username, $_SERVER['REMOTE_ADDR'],time()); //testing the login blocke>
        }
    }
   }

  }
}
?>

<!DOCTYPE html>
<html>
<head>
	    <style type="text/css">

.css1{
position:absolute;top:0px;left:0px;
width:16px;height:16px;
font-family:Arial,sans-serif;
font-size:16px;
text-align:center;
font-weight:bold;
}
.css2{
position:absolute;top:0px;left:0px;
width:10px;height:10px;
font-family:Arial,sans-serif;
font-size:10px;
text-align:center;
}

</style>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

header {
  background-color: green;
  padding: 30px;
  text-align: center;
  font-size: 35px;
  color: black;
}

nav ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

nav li {
  float: left;
}

nav li a {
  display: block;
  color: #f1f1f1;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

nav li a:hover {
 
     background-color: #111;
    }
    section{
        background-color: #f1f1f1;
    }
article {
  float: left;
  padding: 20px;
  width: 50%;
  background-color: #f1f1f1;

}
    
aside {
  float: right;
  padding: 20px;
  width: 50%;
  background-color: #f1f1f1;

}



section:after {
  content: "";
  display: table;
  clear: both;
}


footer {
  background-color: green;
  padding: 10px;
  text-align: center;
  color: green;
}

@media (max-width: 600px) {
  nav, article {
    width: 100%;
    height: auto;
  }
}
</style>
</head>
<body>



<header>
  <h2>Login</h2>
</header>
</head>
<body>

	<!--Taking in input into php is done external to the php tag. Example below-->

	<section class="formforthelogin">
<article>		
<aside>
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" name="loginform" id="loginform">
		<div class="unameinput">
		Username: <input type="username" id="username" name="username">
		</div>
		
		<div class="pw input">
		Password: <input id="password" type="password" name="password"  autocomplete="current-password">
		</div>
		
		<div class="button input"> 
		<button id="submittage" name="submittage" type="submit"> Check </button>
		</div>

</article>
	</form>

<script>
function show_image(src, width, height, alt) {
    var img = document.createElement("img");
    img.src = src;
    img.width = width;
    img.height = height;
    img.alt = alt;
    document.body.appendChild(img);
}
var sorc = 'hospital_image.jpg';
show_image(sorc,152,100,"Hospital");
</script>
</aside>
</section>
    <footer>
  <p></p>
</footer>

</body>
</html>
